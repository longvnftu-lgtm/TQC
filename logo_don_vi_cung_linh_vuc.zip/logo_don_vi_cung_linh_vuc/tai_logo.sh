#!/usr/bin/env bash
# Chạy trong folder này trên máy bạn: bash tai_logo.sh
cd "$(dirname "$0")"
dl(){ curl -sSL -m 30 -o "$1" "$2" && echo "OK  $1" || echo "LỖI $1"; }
dl DTNC_DT-C-Vina.png            "https://cdn0577.cdn4s.com/media/logo/logo.png"
dl BOA.png                       "https://boa.gov.vn/sites/default/files/logo/boa.logo_.new__0.png"
dl PhucGia.png                   "https://phucgia.com.vn/wp-content/uploads/2017/12/Logo_Trong_Nen_Cat_Vien_Tren-e1513583295547.png"
dl Vinasaf.png                   "https://www.vinasaf.com/hinhmenu/logo.png"
dl KhaoNghiemChanNuoi_TT-I.png   "https://khaonghiemchannuoi.vn/wp-content/uploads/2026/02/logo-vn.png"
dl ISOCAL.png                    "https://isocal.vn/wp-content/uploads/2021/01/FA1-1-1.png"
