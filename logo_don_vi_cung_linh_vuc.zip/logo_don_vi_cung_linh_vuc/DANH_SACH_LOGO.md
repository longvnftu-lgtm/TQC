# Logo các đơn vị cùng lĩnh vực đã triển khai

Cách dùng: chạy `bash tai_logo.sh` trong folder này để tải 6 logo về. Sau đó đưa vào slide "Khách hàng cùng lĩnh vực" (xếp hàng ngang, cùng chiều cao, nền trắng, tông xám nếu logo quá nhiều màu).

| # | Đơn vị | Website | File | URL logo gốc |
|---|---|---|---|---|
| 1 | DT&C Vina (DTNC) | https://dtnc.vn/ | DTNC_DT-C-Vina.png | https://cdn0577.cdn4s.com/media/logo/logo.png |
| 2 | Văn phòng Công nhận chất lượng quốc gia (BoA) | https://boa.gov.vn/vi | BOA.png | https://boa.gov.vn/sites/default/files/logo/boa.logo_.new__0.png |
| 3 | Phòng thử nghiệm Phúc Gia | https://phucgia.com.vn/ | PhucGia.png | https://phucgia.com.vn/wp-content/uploads/2017/12/Logo_Trong_Nen_Cat_Vien_Tren-e1513583295547.png |
| 4 | Vinasaf Inspection | https://www.vinasaf.com/trang-chu | Vinasaf.png | https://www.vinasaf.com/hinhmenu/logo.png |
| 5 | Trung tâm Khảo nghiệm, Kiểm nghiệm và Kiểm định Chăn nuôi TW I | https://khaonghiemchannuoi.vn/ | KhaoNghiemChanNuoi_TT-I.png | https://khaonghiemchannuoi.vn/wp-content/uploads/2026/02/logo-vn.png |
| 6 | Hiệu chuẩn ISOCAL | https://isocal.vn/ | ISOCAL.png | https://isocal.vn/wp-content/uploads/2021/01/FA1-1-1.png |

Lưu ý: Logo thuộc quyền của từng đơn vị; chỉ dùng trong tài liệu giới thiệu khi đã có xác nhận họ là khách hàng của Base. Logo Phúc Gia là ảnh 2017, có thể độ phân giải thấp.
